const express=require('express')
const mongoose=require('mongoose')
const bodyParser=require('body-parser')
const ejs=require('ejs')
const app=express()
app.set('view engine','ejs')
app.use(bodyParser.urlencoded({extended:true}))
app.use(express.static("public"))
var post=[]
mongoose.connect("mongodb://localhost:27017/bookmarks",{newUrlParser:true})
const bookmarkSchema= new mongoose.Schema({
  Id:String,
  title:String,
  Link:String,
  timect:{type:Date, time: Date.now},
  timeut:{type:Date, time: Date.now},
  Publisher:String,
  Tags:String
})
const bookmark= mongoose.model("bookmark",bookmarkSchema)
app.get("/",function(req,res){
 
  res.render('index',{post:post})
})
app.post("/",function(req,res){
  const curr= new Date()
const id= Math.floor(Math.random() * 100000)  
const posts= new bookmark({
  Id:id,
  title:req.body.Website,
  Link:req.body.URL,
  timect:{type:curr, time: curr.now},
  timeut:{type:curr, time: curr.now},
  Publisher:req.body.Publisher,
  Tags:req.body.Tags
})
post.push(posts)
res.render('index',{post:post})
})
app.delete("/",function(req,res){
console.log("hello");
const ide=req.body.del
for(let i=0;i<post.length;i++)
{
  if (post[i].id===ide){
    post.splice(i,1)
  }
}
res.redirect("/abc")
})

app.listen(3000,function(){
  console.log("Server is running");
})
